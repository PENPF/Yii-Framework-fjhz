<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'About';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        This is the About page. I literally had no idea of what to put here, so, let's just supose that there is a really beautiful and wonderful page here. :)
    </p>

    <code><?= __FILE__ ?></code>
</div>
